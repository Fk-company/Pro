import { CheckCircle2, Info, AlertTriangle, X } from 'lucide-react';
import { useStore } from '../store';
import { cn } from '../utils/cn';

const typeConfig = {
  success: { icon: CheckCircle2, bg: 'bg-green-500', border: 'border-green-200' },
  info: { icon: Info, bg: 'bg-blue-500', border: 'border-blue-200' },
  warning: { icon: AlertTriangle, bg: 'bg-amber-500', border: 'border-amber-200' },
};

export default function Notifications() {
  const { notifications, clearNotification } = useStore();

  if (notifications.length === 0) return null;

  return (
    <div className="fixed top-4 left-4 z-[70] space-y-3 max-w-sm">
      {notifications.map(n => {
        const config = typeConfig[n.type];
        const Icon = config.icon;
        return (
          <div key={n.id}
            className={cn("bg-white rounded-xl shadow-2xl border p-4 flex items-start gap-3 animate-slide-in", config.border)}>
            <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center text-white flex-shrink-0", config.bg)}>
              <Icon className="w-4 h-4" />
            </div>
            <p className="text-sm text-gray-700 flex-1 pt-1">{n.message}</p>
            <button onClick={() => clearNotification(n.id)} className="text-gray-400 hover:text-gray-600 flex-shrink-0">
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
}
