import { useState, useMemo } from 'react';
import { Wrench, Eye, X, MapPin, User, Phone, Clock, MessageSquare, CheckCircle2, AlertCircle, Image as ImageIcon } from 'lucide-react';
import { useStore } from '../store';
import type { Problem, ProblemStatus, PriorityLevel } from '../types';
import { cn } from '../utils/cn';

const statusConfig: Record<ProblemStatus, { label: string; color: string; bgColor: string }> = {
  'new': { label: 'جديد', color: 'text-gray-700', bgColor: 'bg-gray-100' },
  'in-progress': { label: 'قيد المعالجة', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  'transferred': { label: 'محوّل للصيانة', color: 'text-purple-700', bgColor: 'bg-purple-100' },
  'completed': { label: 'مكتمل', color: 'text-green-700', bgColor: 'bg-green-100' },
  'fixed': { label: 'تم الإصلاح', color: 'text-emerald-700', bgColor: 'bg-emerald-100' },
  'needs-followup': { label: 'يحتاج متابعة', color: 'text-amber-700', bgColor: 'bg-amber-100' },
  'cannot-fix': { label: 'تعذر الإصلاح', color: 'text-red-700', bgColor: 'bg-red-100' },
};

const priorityConfig: Record<PriorityLevel, { label: string; color: string; bgColor: string; emoji: string }> = {
  'A': { label: 'عاجل جداً', color: 'text-red-700', bgColor: 'bg-red-100', emoji: '🔴' },
  'B': { label: 'متوسط', color: 'text-amber-700', bgColor: 'bg-amber-100', emoji: '🟡' },
  'C': { label: 'منخفض', color: 'text-green-700', bgColor: 'bg-green-100', emoji: '🟢' },
};

export default function MaintenancePanel() {
  const { problems, updateProblem } = useStore();
  const [selected, setSelected] = useState<Problem | null>(null);
  const [maintenanceNotes, setMaintenanceNotes] = useState('');
  const [showImageModal, setShowImageModal] = useState<string | null>(null);

  const maintenanceProblems = useMemo(() =>
    problems.filter(p => ['transferred', 'needs-followup'].includes(p.status)),
    [problems]
  );

  const openDetail = (p: Problem) => {
    setSelected(p);
    setMaintenanceNotes(p.maintenanceNotes);
  };

  const saveNotes = () => {
    if (!selected) return;
    updateProblem(selected.id, { maintenanceNotes });
    setSelected({ ...selected, maintenanceNotes });
  };

  const changeStatus = (status: ProblemStatus) => {
    if (!selected) return;
    updateProblem(selected.id, { status, maintenanceNotes });
    setSelected({ ...selected, status, maintenanceNotes });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-500 to-amber-600 rounded-2xl p-6 text-white shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
            <Wrench className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">قسم الصيانة</h2>
            <p className="text-orange-100">الطلبات المحوّلة لفريق الصيانة</p>
          </div>
        </div>
        <div className="mt-4 flex gap-4">
          <div className="bg-white/20 rounded-xl px-4 py-2">
            <span className="text-3xl font-bold">{maintenanceProblems.length}</span>
            <span className="text-sm text-orange-100 mr-2">طلب محوّل</span>
          </div>
          <div className="bg-white/20 rounded-xl px-4 py-2">
            <span className="text-3xl font-bold">{maintenanceProblems.filter(p => p.priority === 'A').length}</span>
            <span className="text-sm text-orange-100 mr-2">عاجل</span>
          </div>
        </div>
      </div>

      {/* Tasks */}
      {maintenanceProblems.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-lg border p-12 text-center">
          <CheckCircle2 className="w-16 h-16 text-green-400 mx-auto mb-4" />
          <p className="text-xl font-bold text-gray-700">لا توجد طلبات حالياً</p>
          <p className="text-gray-400 mt-1">جميع الطلبات تم معالجتها</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {maintenanceProblems.map(p => (
            <div key={p.id} className={cn("bg-white rounded-2xl shadow-lg border p-5 transition-all hover:shadow-xl cursor-pointer",
              p.priority === 'A' && 'border-r-4 border-r-red-500')}>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2 flex-wrap">
                    <span className="font-mono text-sm font-bold text-blue-600">{p.ticketNumber}</span>
                    <span className={cn("px-2.5 py-0.5 rounded-full text-xs font-bold", priorityConfig[p.priority].bgColor, priorityConfig[p.priority].color)}>
                      {priorityConfig[p.priority].emoji} {priorityConfig[p.priority].label}
                    </span>
                    <span className={cn("px-2.5 py-0.5 rounded-full text-xs font-bold", statusConfig[p.status].bgColor, statusConfig[p.status].color)}>
                      {statusConfig[p.status].label}
                    </span>
                  </div>
                  <h3 className="font-bold text-gray-900">{p.title}</h3>
                  <p className="text-gray-600 text-sm mt-1">{p.description}</p>
                  <div className="flex gap-4 mt-3 flex-wrap">
                    <span className="text-xs text-gray-500 flex items-center gap-1"><MapPin className="w-3 h-3" /> {p.location}</span>
                    <span className="text-xs text-gray-500 flex items-center gap-1"><User className="w-3 h-3" /> {p.reportedBy}</span>
                    <span className="text-xs text-gray-500 flex items-center gap-1"><Clock className="w-3 h-3" /> {new Date(p.createdAt).toLocaleDateString('ar-SA')}</span>
                  </div>
                  {p.adminNotes && (
                    <div className="mt-3 bg-blue-50 rounded-lg p-3 border border-blue-100">
                      <p className="text-xs text-blue-600 font-semibold mb-1">ملاحظات الإدارة:</p>
                      <p className="text-blue-800 text-sm">{p.adminNotes}</p>
                    </div>
                  )}
                </div>
                <button onClick={() => openDetail(p)} className="p-3 text-blue-600 hover:bg-blue-50 rounded-xl transition-colors mr-3">
                  <Eye className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Detail Modal */}
      {selected && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-start justify-center p-4 pt-10 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl my-4">
            <div className="p-6 border-b bg-gradient-to-r from-orange-50 to-amber-50 rounded-t-3xl flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">تفاصيل الطلب</p>
                <p className="text-xl font-bold text-orange-700 font-mono">{selected.ticketNumber}</p>
              </div>
              <button onClick={() => setSelected(null)} className="p-2 hover:bg-white/60 rounded-xl">
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>

            <div className="p-6 space-y-5 max-h-[70vh] overflow-y-auto">
              {/* Info */}
              <div className="bg-gray-50 rounded-xl p-4 border">
                <h3 className="font-bold text-gray-900 mb-2">{selected.title}</h3>
                <p className="text-gray-600 text-sm">{selected.description}</p>
                <div className="flex gap-3 mt-3 flex-wrap">
                  <span className="text-xs bg-white px-3 py-1 rounded-lg border flex items-center gap-1"><MapPin className="w-3 h-3" /> {selected.location}</span>
                  <span className="text-xs bg-white px-3 py-1 rounded-lg border flex items-center gap-1"><User className="w-3 h-3" /> {selected.reportedBy}</span>
                  <span className="text-xs bg-white px-3 py-1 rounded-lg border flex items-center gap-1"><Phone className="w-3 h-3" /> <span dir="ltr">{selected.phone}</span></span>
                </div>
              </div>

              {/* Images */}
              {selected.images.length > 0 && (
                <div>
                  <p className="text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                    <ImageIcon className="w-4 h-4" /> صور المشكلة
                  </p>
                  <div className="flex gap-3 flex-wrap">
                    {selected.images.map((img, i) => (
                      <img key={i} src={img} alt={`صورة ${i + 1}`}
                        onClick={() => setShowImageModal(img)}
                        className="w-28 h-28 object-cover rounded-xl border-2 cursor-pointer hover:scale-105 transition-transform" />
                    ))}
                  </div>
                </div>
              )}

              {/* Admin Notes */}
              {selected.adminNotes && (
                <div className="bg-blue-50 rounded-xl p-4 border border-blue-100">
                  <p className="text-sm font-semibold text-blue-700 mb-1 flex items-center gap-2">
                    <MessageSquare className="w-4 h-4" /> ملاحظات الإدارة
                  </p>
                  <p className="text-blue-800 text-sm">{selected.adminNotes}</p>
                </div>
              )}

              {/* Maintenance Notes */}
              <div>
                <p className="text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  <Wrench className="w-4 h-4" /> ملاحظات الصيانة
                </p>
                <textarea value={maintenanceNotes} onChange={e => setMaintenanceNotes(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 resize-none" rows={3}
                  placeholder="أضف ملاحظات الإصلاح هنا..." />
                <button onClick={saveNotes}
                  className="mt-2 px-4 py-2 bg-orange-600 text-white rounded-lg text-sm font-medium hover:bg-orange-700 transition-colors">
                  حفظ الملاحظات
                </button>
              </div>

              {/* Actions */}
              <div className="pt-4 border-t">
                <p className="text-sm font-semibold text-gray-700 mb-3">تحديث الحالة</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <button onClick={() => changeStatus('fixed')}
                    className="py-3 bg-emerald-600 text-white rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200">
                    <CheckCircle2 className="w-4 h-4" /> تم الإصلاح
                  </button>
                  <button onClick={() => changeStatus('needs-followup')}
                    className="py-3 bg-amber-500 text-white rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-amber-600 transition-colors shadow-lg shadow-amber-200">
                    <AlertCircle className="w-4 h-4" /> يحتاج متابعة
                  </button>
                  <button onClick={() => changeStatus('cannot-fix')}
                    className="py-3 bg-red-600 text-white rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-red-700 transition-colors shadow-lg shadow-red-200">
                    <X className="w-4 h-4" /> تعذر الإصلاح
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Image Modal */}
      {showImageModal && (
        <div className="fixed inset-0 z-[60] bg-black/80 flex items-center justify-center p-4" onClick={() => setShowImageModal(null)}>
          <img src={showImageModal} alt="صورة مكبرة" className="max-w-full max-h-[90vh] rounded-2xl shadow-2xl" />
        </div>
      )}
    </div>
  );
}
