import { useState } from 'react';
import { Search, Hash, Phone, Clock, MapPin, User, AlertCircle, CheckCircle2, ArrowLeft, MessageSquare, Wrench, Image as ImageIcon } from 'lucide-react';
import { useStore } from '../store';
import type { Problem, ProblemStatus, PriorityLevel } from '../types';
import { cn } from '../utils/cn';

const statusConfig: Record<ProblemStatus, { label: string; color: string; bgColor: string; icon: typeof AlertCircle }> = {
  'new': { label: 'جديد', color: 'text-gray-700', bgColor: 'bg-gray-100', icon: AlertCircle },
  'in-progress': { label: 'قيد المعالجة', color: 'text-blue-700', bgColor: 'bg-blue-100', icon: Clock },
  'transferred': { label: 'محوّل للصيانة', color: 'text-purple-700', bgColor: 'bg-purple-100', icon: Wrench },
  'completed': { label: 'مكتمل', color: 'text-green-700', bgColor: 'bg-green-100', icon: CheckCircle2 },
  'fixed': { label: 'تم الإصلاح', color: 'text-emerald-700', bgColor: 'bg-emerald-100', icon: CheckCircle2 },
  'needs-followup': { label: 'يحتاج متابعة', color: 'text-amber-700', bgColor: 'bg-amber-100', icon: AlertCircle },
  'cannot-fix': { label: 'تعذر الإصلاح', color: 'text-red-700', bgColor: 'bg-red-100', icon: AlertCircle },
};

const priorityConfig: Record<PriorityLevel, { label: string; color: string; bgColor: string; emoji: string }> = {
  'A': { label: 'عاجل جداً', color: 'text-red-700', bgColor: 'bg-red-100', emoji: '🔴' },
  'B': { label: 'متوسط', color: 'text-amber-700', bgColor: 'bg-amber-100', emoji: '🟡' },
  'C': { label: 'منخفض', color: 'text-green-700', bgColor: 'bg-green-100', emoji: '🟢' },
};

const statusSteps: ProblemStatus[] = ['new', 'in-progress', 'transferred', 'completed'];

function getStepIndex(status: ProblemStatus): number {
  if (status === 'fixed' || status === 'completed') return 3;
  if (status === 'needs-followup') return 2;
  if (status === 'cannot-fix') return 3;
  return statusSteps.indexOf(status);
}

export default function SearchProblem() {
  const { getProblemByTicket, searchProblems } = useStore();
  const [query, setQuery] = useState('');
  const [searchType, setSearchType] = useState<'ticket' | 'phone'>('ticket');
  const [result, setResult] = useState<Problem | null>(null);
  const [results, setResults] = useState<Problem[]>([]);
  const [searched, setSearched] = useState(false);
  const [showImageModal, setShowImageModal] = useState<string | null>(null);

  const handleSearch = () => {
    if (!query.trim()) return;
    setSearched(true);
    setResult(null);
    setResults([]);

    if (searchType === 'ticket') {
      const found = getProblemByTicket(query.trim());
      if (found) setResult(found);
    } else {
      const found = searchProblems(query.trim()).filter(p => p.phone.includes(query.trim()));
      setResults(found);
      if (found.length === 1) setResult(found[0]);
    }
  };

  const stepIndex = result ? getStepIndex(result.status) : 0;

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-3xl shadow-2xl border p-6 md:p-10">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Search className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">تتبع حالة الطلب</h2>
          <p className="text-gray-500 mt-1">أدخل رقم الطلب أو رقم الهاتف للبحث</p>
        </div>

        {/* Search Type Toggle */}
        <div className="flex gap-2 mb-4 bg-gray-100 rounded-xl p-1">
          <button onClick={() => { setSearchType('ticket'); setSearched(false); setResult(null); setResults([]); setQuery(''); }}
            className={cn("flex-1 py-2.5 rounded-lg font-medium text-sm flex items-center justify-center gap-2 transition-all",
              searchType === 'ticket' ? 'bg-white shadow-sm text-blue-700' : 'text-gray-500 hover:text-gray-700')}>
            <Hash className="w-4 h-4" /> رقم الطلب
          </button>
          <button onClick={() => { setSearchType('phone'); setSearched(false); setResult(null); setResults([]); setQuery(''); }}
            className={cn("flex-1 py-2.5 rounded-lg font-medium text-sm flex items-center justify-center gap-2 transition-all",
              searchType === 'phone' ? 'bg-white shadow-sm text-blue-700' : 'text-gray-500 hover:text-gray-700')}>
            <Phone className="w-4 h-4" /> رقم الهاتف
          </button>
        </div>

        {/* Search Input */}
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input type="text" value={query} onChange={e => setQuery(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSearch()}
              className="w-full pr-12 pl-4 py-3.5 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-lg"
              placeholder={searchType === 'ticket' ? 'TK-XXXXXX-XXXX' : '05XXXXXXXX'}
              dir="ltr" />
          </div>
          <button onClick={handleSearch}
            className="px-6 py-3.5 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-bold rounded-xl hover:shadow-lg transition-all">
            بحث
          </button>
        </div>

        {/* Results */}
        {searched && !result && results.length === 0 && (
          <div className="mt-8 text-center py-10">
            <AlertCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 text-lg font-medium">لم يتم العثور على نتائج</p>
            <p className="text-gray-400 text-sm mt-1">تأكد من صحة البيانات المدخلة</p>
          </div>
        )}

        {results.length > 1 && !result && (
          <div className="mt-6 space-y-3">
            <p className="text-gray-600 font-medium">تم العثور على {results.length} نتائج:</p>
            {results.map(r => (
              <button key={r.id} onClick={() => setResult(r)}
                className="w-full text-right p-4 bg-gray-50 hover:bg-blue-50 rounded-xl border transition-colors flex items-center justify-between">
                <div>
                  <p className="font-bold text-gray-900">{r.ticketNumber}</p>
                  <p className="text-gray-600 text-sm">{r.title}</p>
                </div>
                <ArrowLeft className="w-5 h-5 text-gray-400" />
              </button>
            ))}
          </div>
        )}

        {/* Detail View */}
        {result && (
          <div className="mt-8 space-y-6">
            {results.length > 1 && (
              <button onClick={() => setResult(null)} className="text-blue-600 text-sm flex items-center gap-1 hover:underline">
                <ArrowLeft className="w-4 h-4 rotate-180" /> العودة للنتائج
              </button>
            )}

            {/* Ticket Header */}
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-6 border border-blue-100">
              <div className="flex items-center justify-between flex-wrap gap-4">
                <div>
                  <p className="text-sm text-gray-500">رقم الطلب</p>
                  <p className="text-2xl font-bold text-blue-700 font-mono">{result.ticketNumber}</p>
                </div>
                <div className="flex gap-3">
                  <span className={cn("px-4 py-2 rounded-full text-sm font-bold", statusConfig[result.status].bgColor, statusConfig[result.status].color)}>
                    {statusConfig[result.status].label}
                  </span>
                  <span className={cn("px-4 py-2 rounded-full text-sm font-bold", priorityConfig[result.priority].bgColor, priorityConfig[result.priority].color)}>
                    {priorityConfig[result.priority].emoji} {priorityConfig[result.priority].label}
                  </span>
                </div>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="bg-white rounded-2xl p-6 border">
              <h3 className="text-sm font-bold text-gray-700 mb-4">مراحل المعالجة</h3>
              <div className="flex items-center justify-between relative">
                <div className="absolute top-4 right-4 left-4 h-1 bg-gray-200 rounded-full">
                  <div className="h-full bg-gradient-to-l from-blue-500 to-green-500 rounded-full transition-all duration-500"
                    style={{ width: `${(stepIndex / (statusSteps.length - 1)) * 100}%` }} />
                </div>
                {statusSteps.map((step, i) => {
                  const config = statusConfig[step];
                  const Icon = config.icon;
                  const isActive = i <= stepIndex;
                  const isCurrent = i === stepIndex;
                  return (
                    <div key={step} className="relative z-10 flex flex-col items-center">
                      <div className={cn("w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all",
                        isCurrent ? 'bg-blue-600 border-blue-600 text-white scale-125 shadow-lg' :
                          isActive ? 'bg-green-500 border-green-500 text-white' : 'bg-white border-gray-300 text-gray-400')}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <p className={cn("text-xs mt-2 font-medium text-center", isCurrent ? 'text-blue-700' : isActive ? 'text-green-700' : 'text-gray-400')}>
                        {config.label}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Details Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-xl p-4 border">
                <div className="flex items-center gap-2 mb-3 text-gray-600">
                  <User className="w-4 h-4" /> <span className="text-sm font-semibold">معلومات المبلّغ</span>
                </div>
                <div className="space-y-2 text-sm">
                  <p><span className="text-gray-500">الاسم:</span> <span className="font-medium">{result.reportedBy}</span></p>
                  <p><span className="text-gray-500">الهاتف:</span> <span className="font-medium font-mono" dir="ltr">{result.phone}</span></p>
                  {result.email && <p><span className="text-gray-500">البريد:</span> <span className="font-medium">{result.email}</span></p>}
                </div>
              </div>
              <div className="bg-gray-50 rounded-xl p-4 border">
                <div className="flex items-center gap-2 mb-3 text-gray-600">
                  <Clock className="w-4 h-4" /> <span className="text-sm font-semibold">التواريخ</span>
                </div>
                <div className="space-y-2 text-sm">
                  <p><span className="text-gray-500">تاريخ الإنشاء:</span> <span className="font-medium">{new Date(result.createdAt).toLocaleString('ar-SA')}</span></p>
                  <p><span className="text-gray-500">آخر تحديث:</span> <span className="font-medium">{new Date(result.updatedAt).toLocaleString('ar-SA')}</span></p>
                </div>
              </div>
            </div>

            {/* Problem Details */}
            <div className="bg-gray-50 rounded-xl p-5 border">
              <h3 className="font-bold text-gray-800 mb-2">{result.title}</h3>
              <p className="text-gray-600 leading-relaxed">{result.description}</p>
              <div className="flex gap-4 mt-4 flex-wrap">
                <span className="text-sm bg-white px-3 py-1 rounded-lg border"><MapPin className="w-3 h-3 inline ml-1" />{result.location}</span>
                <span className="text-sm bg-white px-3 py-1 rounded-lg border">📂 {result.category}</span>
              </div>
            </div>

            {/* Images */}
            {result.images.length > 0 && (
              <div className="bg-gray-50 rounded-xl p-5 border">
                <div className="flex items-center gap-2 mb-3">
                  <ImageIcon className="w-4 h-4 text-gray-600" />
                  <span className="text-sm font-semibold text-gray-700">صور المشكلة ({result.images.length})</span>
                </div>
                <div className="flex gap-3 flex-wrap">
                  {result.images.map((img, i) => (
                    <img key={i} src={img} alt={`صورة ${i + 1}`}
                      onClick={() => setShowImageModal(img)}
                      className="w-28 h-28 object-cover rounded-xl border-2 border-gray-200 cursor-pointer hover:scale-105 transition-transform shadow-sm" />
                  ))}
                </div>
              </div>
            )}

            {/* Notes */}
            {(result.adminNotes || result.maintenanceNotes) && (
              <div className="space-y-3">
                {result.adminNotes && (
                  <div className="bg-blue-50 rounded-xl p-4 border border-blue-100">
                    <div className="flex items-center gap-2 mb-2">
                      <MessageSquare className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-semibold text-blue-700">ملاحظات الإدارة</span>
                    </div>
                    <p className="text-blue-800 text-sm">{result.adminNotes}</p>
                  </div>
                )}
                {result.maintenanceNotes && (
                  <div className="bg-orange-50 rounded-xl p-4 border border-orange-100">
                    <div className="flex items-center gap-2 mb-2">
                      <Wrench className="w-4 h-4 text-orange-600" />
                      <span className="text-sm font-semibold text-orange-700">ملاحظات الصيانة</span>
                    </div>
                    <p className="text-orange-800 text-sm">{result.maintenanceNotes}</p>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Image Modal */}
      {showImageModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4" onClick={() => setShowImageModal(null)}>
          <img src={showImageModal} alt="صورة مكبرة" className="max-w-full max-h-[90vh] rounded-2xl shadow-2xl" />
        </div>
      )}
    </div>
  );
}
