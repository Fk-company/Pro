import { useState, useMemo } from 'react';
import {
  BarChart3, AlertTriangle, Clock, CheckCircle2, Wrench, Search, Filter, Eye, Trash2,
  FileSpreadsheet, Download, MapPin, User, Phone, Mail, MessageSquare, Send, X,
  ChevronDown, ChevronUp, Image as ImageIcon, ArrowUpCircle, LogOut
} from 'lucide-react';
import { useStore } from '../store';
import type { Problem, ProblemStatus, PriorityLevel } from '../types';
import { cn } from '../utils/cn';
import * as XLSX from 'xlsx';

const statusConfig: Record<ProblemStatus, { label: string; color: string; bgColor: string }> = {
  'new': { label: 'جديد', color: 'text-gray-700', bgColor: 'bg-gray-100' },
  'in-progress': { label: 'قيد المعالجة', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  'transferred': { label: 'محوّل للصيانة', color: 'text-purple-700', bgColor: 'bg-purple-100' },
  'completed': { label: 'مكتمل', color: 'text-green-700', bgColor: 'bg-green-100' },
  'fixed': { label: 'تم الإصلاح', color: 'text-emerald-700', bgColor: 'bg-emerald-100' },
  'needs-followup': { label: 'يحتاج متابعة', color: 'text-amber-700', bgColor: 'bg-amber-100' },
  'cannot-fix': { label: 'تعذر الإصلاح', color: 'text-red-700', bgColor: 'bg-red-100' },
};

const priorityConfig: Record<PriorityLevel, { label: string; color: string; bgColor: string; emoji: string }> = {
  'A': { label: 'عاجل جداً', color: 'text-red-700', bgColor: 'bg-red-100', emoji: '🔴' },
  'B': { label: 'متوسط', color: 'text-amber-700', bgColor: 'bg-amber-100', emoji: '🟡' },
  'C': { label: 'منخفض', color: 'text-green-700', bgColor: 'bg-green-100', emoji: '🟢' },
};

interface Props {
  onLogout: () => void;
}

export default function AdminDashboard({ onLogout }: Props) {
  const { problems, updateProblem, deleteProblem } = useStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<ProblemStatus | 'all'>('all');
  const [filterPriority, setFilterPriority] = useState<PriorityLevel | 'all'>('all');
  const [selectedProblem, setSelectedProblem] = useState<Problem | null>(null);
  const [adminNotes, setAdminNotes] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [showImageModal, setShowImageModal] = useState<string | null>(null);

  const stats = useMemo(() => ({
    total: problems.length,
    new: problems.filter(p => p.status === 'new').length,
    inProgress: problems.filter(p => p.status === 'in-progress').length,
    transferred: problems.filter(p => p.status === 'transferred').length,
    completed: problems.filter(p => ['completed', 'fixed'].includes(p.status)).length,
    critical: problems.filter(p => p.priority === 'A').length,
    medium: problems.filter(p => p.priority === 'B').length,
    low: problems.filter(p => p.priority === 'C').length,
  }), [problems]);

  const filtered = useMemo(() => {
    return problems.filter(p => {
      const matchSearch = !searchQuery ||
        p.ticketNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.reportedBy.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.phone.includes(searchQuery);
      const matchStatus = filterStatus === 'all' || p.status === filterStatus;
      const matchPriority = filterPriority === 'all' || p.priority === filterPriority;
      return matchSearch && matchStatus && matchPriority;
    });
  }, [problems, searchQuery, filterStatus, filterPriority]);

  const exportToExcel = () => {
    const data = problems.map(p => ({
      'رقم الطلب': p.ticketNumber,
      'العنوان': p.title,
      'الوصف': p.description,
      'التصنيف': p.category,
      'الأولوية': priorityConfig[p.priority].label,
      'الحالة': statusConfig[p.status].label,
      'الموقع': p.location,
      'المبلّغ': p.reportedBy,
      'الهاتف': p.phone,
      'البريد': p.email,
      'تاريخ الإنشاء': new Date(p.createdAt).toLocaleString('ar-SA'),
      'آخر تحديث': new Date(p.updatedAt).toLocaleString('ar-SA'),
      'ملاحظات الإدارة': p.adminNotes,
      'ملاحظات الصيانة': p.maintenanceNotes,
      'معيّن إلى': p.assignedTo,
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'البلاغات');
    XLSX.writeFile(wb, `بلاغات_${new Date().toLocaleDateString('ar-SA')}.xlsx`);
  };

  const openDetail = (p: Problem) => {
    setSelectedProblem(p);
    setAdminNotes(p.adminNotes);
  };

  const saveNotes = () => {
    if (!selectedProblem) return;
    updateProblem(selectedProblem.id, { adminNotes });
    setSelectedProblem({ ...selectedProblem, adminNotes });
  };

  const changeStatus = (status: ProblemStatus) => {
    if (!selectedProblem) return;
    updateProblem(selectedProblem.id, { status });
    setSelectedProblem({ ...selectedProblem, status });
  };

  const changePriority = (priority: PriorityLevel) => {
    if (!selectedProblem) return;
    updateProblem(selectedProblem.id, { priority });
    setSelectedProblem({ ...selectedProblem, priority });
  };

  const transferToMaintenance = () => {
    if (!selectedProblem) return;
    updateProblem(selectedProblem.id, { status: 'transferred' as ProblemStatus });
    setSelectedProblem({ ...selectedProblem, status: 'transferred' as ProblemStatus });
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا البلاغ؟')) {
      deleteProblem(id);
      if (selectedProblem?.id === id) setSelectedProblem(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <BarChart3 className="w-7 h-7 text-blue-600" /> لوحة التحكم
          </h2>
          <p className="text-gray-500 text-sm">إدارة ومتابعة جميع البلاغات</p>
        </div>
        <div className="flex gap-3">
          <button onClick={exportToExcel}
            className="px-4 py-2.5 bg-green-600 hover:bg-green-700 text-white rounded-xl flex items-center gap-2 font-medium shadow-lg shadow-green-200 transition-all">
            <Download className="w-4 h-4" /> تصدير Excel
          </button>
          <button onClick={onLogout}
            className="px-4 py-2.5 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-xl flex items-center gap-2 font-medium transition-all">
            <LogOut className="w-4 h-4" /> خروج
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-5 text-white shadow-lg shadow-blue-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm">إجمالي البلاغات</p>
              <p className="text-4xl font-bold mt-1">{stats.total}</p>
            </div>
            <FileSpreadsheet className="w-10 h-10 text-blue-200" />
          </div>
        </div>
        <div className="bg-gradient-to-br from-amber-500 to-orange-500 rounded-2xl p-5 text-white shadow-lg shadow-amber-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-amber-100 text-sm">بلاغات جديدة</p>
              <p className="text-4xl font-bold mt-1">{stats.new}</p>
            </div>
            <AlertTriangle className="w-10 h-10 text-amber-200" />
          </div>
        </div>
        <div className="bg-gradient-to-br from-purple-500 to-indigo-600 rounded-2xl p-5 text-white shadow-lg shadow-purple-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm">قيد المعالجة</p>
              <p className="text-4xl font-bold mt-1">{stats.inProgress + stats.transferred}</p>
            </div>
            <Clock className="w-10 h-10 text-purple-200" />
          </div>
        </div>
        <div className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl p-5 text-white shadow-lg shadow-green-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm">مكتملة</p>
              <p className="text-4xl font-bold mt-1">{stats.completed}</p>
            </div>
            <CheckCircle2 className="w-10 h-10 text-green-200" />
          </div>
        </div>
      </div>

      {/* Priority Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-red-50 rounded-xl p-4 border border-red-100 flex items-center justify-between">
          <div>
            <p className="text-red-600 text-sm font-medium">🔴 عاجل (A)</p>
            <p className="text-3xl font-bold text-red-700 mt-1">{stats.critical}</p>
          </div>
          <ArrowUpCircle className="w-8 h-8 text-red-300" />
        </div>
        <div className="bg-amber-50 rounded-xl p-4 border border-amber-100 flex items-center justify-between">
          <div>
            <p className="text-amber-600 text-sm font-medium">🟡 متوسط (B)</p>
            <p className="text-3xl font-bold text-amber-700 mt-1">{stats.medium}</p>
          </div>
          <ArrowUpCircle className="w-8 h-8 text-amber-300" />
        </div>
        <div className="bg-green-50 rounded-xl p-4 border border-green-100 flex items-center justify-between">
          <div>
            <p className="text-green-600 text-sm font-medium">🟢 منخفض (C)</p>
            <p className="text-3xl font-bold text-green-700 mt-1">{stats.low}</p>
          </div>
          <ArrowUpCircle className="w-8 h-8 text-green-300" />
        </div>
      </div>

      {/* Search & Filter */}
      <div className="bg-white rounded-2xl shadow-lg border p-5">
        <div className="flex gap-3 flex-wrap">
          <div className="flex-1 min-w-[250px] relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
              className="w-full pr-10 pl-4 py-2.5 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="بحث بالرقم أو العنوان أو الاسم أو الهاتف..." />
          </div>
          <button onClick={() => setShowFilters(!showFilters)}
            className="px-4 py-2.5 border-2 border-gray-200 rounded-xl flex items-center gap-2 hover:bg-gray-50 transition-colors">
            <Filter className="w-4 h-4" /> فلترة
            {showFilters ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
        {showFilters && (
          <div className="mt-4 pt-4 border-t flex gap-4 flex-wrap">
            <div>
              <label className="text-xs text-gray-500 mb-1 block">الحالة</label>
              <select value={filterStatus} onChange={e => setFilterStatus(e.target.value as ProblemStatus | 'all')}
                className="px-3 py-2 border rounded-lg text-sm">
                <option value="all">جميع الحالات</option>
                {Object.entries(statusConfig).map(([k, v]) => (
                  <option key={k} value={k}>{v.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs text-gray-500 mb-1 block">الأولوية</label>
              <select value={filterPriority} onChange={e => setFilterPriority(e.target.value as PriorityLevel | 'all')}
                className="px-3 py-2 border rounded-lg text-sm">
                <option value="all">جميع الأولويات</option>
                {Object.entries(priorityConfig).map(([k, v]) => (
                  <option key={k} value={k}>{v.emoji} {v.label}</option>
                ))}
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Problems Table */}
      <div className="bg-white rounded-2xl shadow-lg border overflow-hidden">
        <div className="p-5 border-b flex items-center justify-between">
          <h3 className="font-bold text-gray-900">البلاغات ({filtered.length})</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 text-xs text-gray-500 uppercase">
              <tr>
                <th className="px-4 py-3 text-right">رقم الطلب</th>
                <th className="px-4 py-3 text-right">المشكلة</th>
                <th className="px-4 py-3 text-right">المبلّغ</th>
                <th className="px-4 py-3 text-right">الأولوية</th>
                <th className="px-4 py-3 text-right">الحالة</th>
                <th className="px-4 py-3 text-right">التاريخ</th>
                <th className="px-4 py-3 text-right">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {filtered.map(p => (
                <tr key={p.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3">
                    <span className="font-mono text-sm font-bold text-blue-600">{p.ticketNumber}</span>
                  </td>
                  <td className="px-4 py-3">
                    <p className="font-medium text-gray-900 text-sm">{p.title}</p>
                    <p className="text-xs text-gray-500 mt-0.5 flex items-center gap-1">
                      <MapPin className="w-3 h-3" /> {p.location}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    <p className="text-sm text-gray-700">{p.reportedBy}</p>
                    <p className="text-xs text-gray-400 font-mono" dir="ltr">{p.phone}</p>
                  </td>
                  <td className="px-4 py-3">
                    <span className={cn("px-2.5 py-1 rounded-full text-xs font-bold", priorityConfig[p.priority].bgColor, priorityConfig[p.priority].color)}>
                      {priorityConfig[p.priority].emoji} {p.priority}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={cn("px-2.5 py-1 rounded-full text-xs font-bold", statusConfig[p.status].bgColor, statusConfig[p.status].color)}>
                      {statusConfig[p.status].label}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-500">
                    {new Date(p.createdAt).toLocaleDateString('ar-SA')}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1">
                      <button onClick={() => openDetail(p)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg" title="عرض">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button onClick={() => handleDelete(p.id)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg" title="حذف">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="text-center py-12">
              <Search className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">لا توجد بلاغات</p>
            </div>
          )}
        </div>
      </div>

      {/* Detail Modal */}
      {selectedProblem && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-start justify-center p-4 pt-10 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-3xl my-4">
            {/* Modal Header */}
            <div className="p-6 border-b flex items-center justify-between bg-gradient-to-r from-blue-50 to-indigo-50 rounded-t-3xl">
              <div>
                <p className="text-sm text-gray-500">تفاصيل البلاغ</p>
                <p className="text-xl font-bold text-blue-700 font-mono">{selectedProblem.ticketNumber}</p>
              </div>
              <button onClick={() => setSelectedProblem(null)} className="p-2 hover:bg-white/60 rounded-xl transition-colors">
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>

            <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
              {/* Status & Priority */}
              <div className="flex gap-3 flex-wrap">
                <span className={cn("px-4 py-2 rounded-full text-sm font-bold", statusConfig[selectedProblem.status].bgColor, statusConfig[selectedProblem.status].color)}>
                  {statusConfig[selectedProblem.status].label}
                </span>
                <span className={cn("px-4 py-2 rounded-full text-sm font-bold", priorityConfig[selectedProblem.priority].bgColor, priorityConfig[selectedProblem.priority].color)}>
                  {priorityConfig[selectedProblem.priority].emoji} {priorityConfig[selectedProblem.priority].label}
                </span>
              </div>

              {/* Problem Info */}
              <div className="bg-gray-50 rounded-xl p-5 border">
                <h3 className="font-bold text-gray-900 text-lg mb-2">{selectedProblem.title}</h3>
                <p className="text-gray-600 leading-relaxed">{selectedProblem.description}</p>
                <div className="flex gap-4 mt-3">
                  <span className="text-sm text-gray-500 flex items-center gap-1"><MapPin className="w-3 h-3" /> {selectedProblem.location}</span>
                  <span className="text-sm text-gray-500">📂 {selectedProblem.category}</span>
                </div>
              </div>

              {/* Reporter */}
              <div className="bg-gray-50 rounded-xl p-5 border grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-gray-400" />
                  <div><p className="text-xs text-gray-500">المبلّغ</p><p className="font-medium text-sm">{selectedProblem.reportedBy}</p></div>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-gray-400" />
                  <div><p className="text-xs text-gray-500">الهاتف</p><p className="font-medium text-sm font-mono" dir="ltr">{selectedProblem.phone}</p></div>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-gray-400" />
                  <div><p className="text-xs text-gray-500">البريد</p><p className="font-medium text-sm">{selectedProblem.email || '-'}</p></div>
                </div>
              </div>

              {/* Images */}
              {selectedProblem.images.length > 0 && (
                <div>
                  <p className="text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                    <ImageIcon className="w-4 h-4" /> صور المشكلة
                  </p>
                  <div className="flex gap-3 flex-wrap">
                    {selectedProblem.images.map((img, i) => (
                      <img key={i} src={img} alt={`صورة ${i + 1}`}
                        onClick={() => setShowImageModal(img)}
                        className="w-32 h-32 object-cover rounded-xl border-2 cursor-pointer hover:scale-105 transition-transform" />
                    ))}
                  </div>
                </div>
              )}

              {/* Change Priority */}
              <div>
                <p className="text-sm font-semibold text-gray-700 mb-2">تغيير التصنيف / الأولوية</p>
                <div className="flex gap-2">
                  {(['A', 'B', 'C'] as PriorityLevel[]).map(p => (
                    <button key={p} onClick={() => changePriority(p)}
                      className={cn("flex-1 py-2.5 rounded-xl font-bold text-sm border-2 transition-all",
                        selectedProblem.priority === p
                          ? p === 'A' ? 'bg-red-500 text-white border-red-500' : p === 'B' ? 'bg-amber-500 text-white border-amber-500' : 'bg-green-500 text-white border-green-500'
                          : 'border-gray-200 text-gray-500 hover:border-gray-300')}>
                      {priorityConfig[p].emoji} {p} - {priorityConfig[p].label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Change Status */}
              <div>
                <p className="text-sm font-semibold text-gray-700 mb-2">تغيير الحالة</p>
                <div className="flex gap-2 flex-wrap">
                  {(['new', 'in-progress', 'transferred', 'completed'] as ProblemStatus[]).map(s => (
                    <button key={s} onClick={() => changeStatus(s)}
                      className={cn("px-4 py-2 rounded-xl text-sm font-medium border-2 transition-all",
                        selectedProblem.status === s
                          ? `${statusConfig[s].bgColor} ${statusConfig[s].color} border-current`
                          : 'border-gray-200 text-gray-500 hover:border-gray-300')}>
                      {statusConfig[s].label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Admin Notes */}
              <div>
                <p className="text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  <MessageSquare className="w-4 h-4" /> ملاحظات الإدارة
                </p>
                <textarea value={adminNotes} onChange={e => setAdminNotes(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 resize-none" rows={3}
                  placeholder="أضف ملاحظاتك هنا..." />
                <button onClick={saveNotes}
                  className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
                  حفظ الملاحظات
                </button>
              </div>

              {/* Maintenance Notes */}
              {selectedProblem.maintenanceNotes && (
                <div className="bg-orange-50 rounded-xl p-4 border border-orange-100">
                  <p className="text-sm font-semibold text-orange-700 mb-1 flex items-center gap-2">
                    <Wrench className="w-4 h-4" /> ملاحظات الصيانة
                  </p>
                  <p className="text-orange-800 text-sm">{selectedProblem.maintenanceNotes}</p>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-3 pt-4 border-t">
                <button onClick={transferToMaintenance}
                  className="flex-1 py-3 bg-purple-600 text-white rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-purple-700 transition-colors shadow-lg shadow-purple-200">
                  <Send className="w-4 h-4" /> إرسال للصيانة
                </button>
                <button onClick={() => changeStatus('completed')}
                  className="flex-1 py-3 bg-green-600 text-white rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-green-700 transition-colors shadow-lg shadow-green-200">
                  <CheckCircle2 className="w-4 h-4" /> إغلاق كمكتمل
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Image Modal */}
      {showImageModal && (
        <div className="fixed inset-0 z-[60] bg-black/80 flex items-center justify-center p-4" onClick={() => setShowImageModal(null)}>
          <img src={showImageModal} alt="صورة مكبرة" className="max-w-full max-h-[90vh] rounded-2xl shadow-2xl" />
        </div>
      )}
    </div>
  );
}
