import { useState, useRef } from 'react';
import { Send, Upload, X, Camera, MapPin, CheckCircle2, AlertTriangle, Image as ImageIcon } from 'lucide-react';
import { useStore } from '../store';
import type { PriorityLevel } from '../types';
import { cn } from '../utils/cn';

const categories = ['صيانة', 'كهرباء', 'سباكة', 'شبكات', 'نجارة', 'تكييف', 'نظافة', 'أخرى'];

export default function SubmitProblem() {
  const { addProblem } = useStore();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState(categories[0]);
  const [priority, setPriority] = useState<PriorityLevel>('B');
  const [location, setLocation] = useState('');
  const [reportedBy, setReportedBy] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [ticketNumber, setTicketNumber] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new window.Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const maxSize = 800;
          let { width, height } = img;
          if (width > maxSize || height > maxSize) {
            if (width > height) {
              height = (height / width) * maxSize;
              width = maxSize;
            } else {
              width = (width / height) * maxSize;
              height = maxSize;
            }
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d')!;
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', 0.7));
        };
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const newImages: string[] = [];
    for (let i = 0; i < Math.min(files.length, 5 - images.length); i++) {
      const compressed = await compressImage(files[i]);
      newImages.push(compressed);
    }
    setImages(prev => [...prev, ...newImages]);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};
    if (!title.trim()) newErrors.title = 'عنوان المشكلة مطلوب';
    if (!description.trim()) newErrors.description = 'وصف المشكلة مطلوب';
    if (!reportedBy.trim()) newErrors.reportedBy = 'الاسم مطلوب';
    if (!phone.trim()) newErrors.phone = 'رقم الهاتف مطلوب';
    if (!location.trim()) newErrors.location = 'الموقع مطلوب';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setIsSubmitting(true);
    setTimeout(() => {
      const ticket = addProblem({
        title, description, category, priority, location,
        reportedBy, phone, email, images,
      });
      setTicketNumber(ticket);
      setSubmitted(true);
      setIsSubmitting(false);
    }, 1200);
  };

  const resetForm = () => {
    setTitle(''); setDescription(''); setCategory(categories[0]);
    setPriority('B'); setLocation(''); setReportedBy('');
    setPhone(''); setEmail(''); setImages([]);
    setSubmitted(false); setTicketNumber(''); setErrors({});
  };

  if (submitted) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-3xl shadow-2xl border border-green-100 p-8 md:p-12 text-center">
          <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-14 h-14 text-green-600" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-3">تم إرسال البلاغ بنجاح!</h2>
          <p className="text-gray-600 mb-6">سيتم مراجعة بلاغك والتعامل معه في أقرب وقت</p>
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-6 mb-8 border border-blue-100">
            <p className="text-sm text-gray-600 mb-2">رقم الطلب الخاص بك</p>
            <p className="text-4xl font-bold text-blue-700 tracking-wider font-mono">{ticketNumber}</p>
            <p className="text-sm text-gray-500 mt-3">احتفظ بهذا الرقم لمتابعة حالة طلبك</p>
          </div>
          <button onClick={resetForm}
            className="px-8 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl font-medium hover:shadow-lg transition-all">
            تقديم بلاغ جديد
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-3xl shadow-2xl border p-6 md:p-10">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <AlertTriangle className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">تقديم بلاغ جديد</h2>
          <p className="text-gray-500 mt-1">يرجى ملء البيانات التالية بدقة لتسريع معالجة المشكلة</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Title */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">عنوان المشكلة *</label>
            <input type="text" value={title} onChange={e => setTitle(e.target.value)}
              className={cn("w-full px-4 py-3 border-2 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all", errors.title ? 'border-red-400' : 'border-gray-200')}
              placeholder="مثال: عطل في نظام التكييف" />
            {errors.title && <p className="text-red-500 text-xs mt-1">{errors.title}</p>}
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">وصف المشكلة *</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} rows={4}
              className={cn("w-full px-4 py-3 border-2 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all resize-none", errors.description ? 'border-red-400' : 'border-gray-200')}
              placeholder="اشرح المشكلة بالتفصيل..." />
            {errors.description && <p className="text-red-500 text-xs mt-1">{errors.description}</p>}
          </div>

          {/* Category & Priority */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">تصنيف المشكلة</label>
              <select value={category} onChange={e => setCategory(e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">الأولوية</label>
              <div className="flex gap-2">
                {(['A', 'B', 'C'] as PriorityLevel[]).map(p => (
                  <button key={p} type="button" onClick={() => setPriority(p)}
                    className={cn("flex-1 py-3 rounded-xl font-bold text-sm border-2 transition-all",
                      priority === p
                        ? p === 'A' ? 'bg-red-500 text-white border-red-500 shadow-lg shadow-red-200'
                          : p === 'B' ? 'bg-amber-500 text-white border-amber-500 shadow-lg shadow-amber-200'
                            : 'bg-green-500 text-white border-green-500 shadow-lg shadow-green-200'
                        : 'border-gray-200 text-gray-600 hover:border-gray-300'
                    )}>
                    {p === 'A' ? '🔴 عاجل' : p === 'B' ? '🟡 متوسط' : '🟢 منخفض'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Location */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              <MapPin className="w-4 h-4 inline ml-1" /> الموقع *
            </label>
            <input type="text" value={location} onChange={e => setLocation(e.target.value)}
              className={cn("w-full px-4 py-3 border-2 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all", errors.location ? 'border-red-400' : 'border-gray-200')}
              placeholder="مثال: المبنى الرئيسي - الطابق الثاني - مكتب 201" />
            {errors.location && <p className="text-red-500 text-xs mt-1">{errors.location}</p>}
          </div>

          {/* Reporter Info */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">الاسم *</label>
              <input type="text" value={reportedBy} onChange={e => setReportedBy(e.target.value)}
                className={cn("w-full px-4 py-3 border-2 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all", errors.reportedBy ? 'border-red-400' : 'border-gray-200')}
                placeholder="الاسم الكامل" />
              {errors.reportedBy && <p className="text-red-500 text-xs mt-1">{errors.reportedBy}</p>}
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">رقم الهاتف *</label>
              <input type="tel" value={phone} onChange={e => setPhone(e.target.value)}
                className={cn("w-full px-4 py-3 border-2 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all", errors.phone ? 'border-red-400' : 'border-gray-200')}
                placeholder="05XXXXXXXX" />
              {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">البريد الإلكتروني</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                placeholder="example@mail.com" />
            </div>
          </div>

          {/* Image Upload */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              <Camera className="w-4 h-4 inline ml-1" /> صور المشكلة (حتى 5 صور)
            </label>
            <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-blue-400 transition-colors cursor-pointer"
              onClick={() => fileInputRef.current?.click()}>
              <Upload className="w-10 h-10 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-600 font-medium">اضغط لرفع الصور أو اسحبها هنا</p>
              <p className="text-gray-400 text-sm mt-1">JPG, PNG - حد أقصى 5 صور</p>
            </div>
            <input ref={fileInputRef} type="file" accept="image/*" multiple onChange={handleImageUpload} className="hidden" />
            {images.length > 0 && (
              <div className="flex gap-3 mt-4 flex-wrap">
                {images.map((img, i) => (
                  <div key={i} className="relative group">
                    <img src={img} alt={`صورة ${i + 1}`} className="w-24 h-24 object-cover rounded-xl border-2 border-gray-200 shadow-sm" />
                    <button type="button" onClick={() => removeImage(i)}
                      className="absolute -top-2 -left-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md">
                      <X className="w-3 h-3" />
                    </button>
                    <div className="absolute bottom-1 right-1 bg-black/50 text-white text-xs px-1.5 py-0.5 rounded">
                      <ImageIcon className="w-3 h-3 inline" /> {i + 1}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Submit */}
          <button type="submit" disabled={isSubmitting}
            className="w-full py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold text-lg rounded-xl shadow-lg hover:shadow-xl hover:from-blue-700 hover:to-indigo-700 transition-all disabled:opacity-50 flex items-center justify-center gap-3">
            {isSubmitting ? (
              <><div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin" /> جاري الإرسال...</>
            ) : (
              <><Send className="w-5 h-5" /> إرسال البلاغ</>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
